/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;

/**
 *
 * @author utpl
 */
abstract class Jugo {

    protected String nombreJugo;
    protected double precioBase;
    protected double porcentajeIva;
    protected double precioIva;
    protected double precioFinal;

    public Jugo(String a, double b, double c) {
        nombreJugo = a;
        precioBase = b;
        porcentajeIva = c;
    }

    public void establecerNombreJugo(String n) {
        nombreJugo = n;
    }

    public void establecerPrecioBase(double n) {
        precioBase = n;
    }

    public void establecerPorcentajeIVA(double n) {
        porcentajeIva = n;
    }

    public abstract void calcularPrecioIVA();

    public abstract void calcularPrecioFinal();

    public String obtenerNombreJugo() {
        return nombreJugo;
    }

    public double obtenerPrecioBase() {
        return precioBase;
    }

    public double obtenerPorcentajeIVA() {
        return porcentajeIva;
    }

    public double obtenerPrecioIVA() {
        return precioIva;
    }

    public double obtenerPrecioFinal() {
        return precioFinal;
    }

}
