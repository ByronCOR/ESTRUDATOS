/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;
import java.util.ArrayList;
/**
 *
 * @author utpl
 */
public class Factura {
  

    private Cliente cliente;
    private ArrayList<Jugo> jugos = new ArrayList<>();
    private double subtotalJugosFactura;
    private double totalArriendosBaseMensual;

    public Factura(Cliente n, ArrayList<Jugo> lista) {
        cliente = n;
        jugos = lista;
    }

    public void establecerCliente(Cliente n) {
        cliente = n;
    }

    public void establecerJugos(ArrayList<Jugo> lista) {
        jugos = lista;
    }
    
      public void establecerIvaFactura() {
        jugos = lista;
    }

    public void establecerSubtotalValorJugos() {
        for (int i = 0; i < obtenerJugos().size(); i++) {
            subtotalJugosFactura = subtotalJugosFactura
                    + obtenerJugos().get(i).obtenerPrecioFinal();
        }
        if()
    }

    

    public Cliente obtenerCliente() {
        return cliente;
    }

    public ArrayList<Jugo> obtenerJugos() {
        return jugos;
    }



   

    @
