/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;

/**
 *
 * @author utpl
 */
public class JugosKids extends Jugo {
        private double valorPorcionFruta;
        private double valorPorcionYogurt;

    public JugosKids(String a, double b, double c, double vf,double vy) {
        super(a, b, c);
        valorPorcionFruta = vf;
                valorPorcionYogurt = vy;
    }
    
        public void EstablecerValorPorcionFruta(double n) {
        valorPorcionFruta = n;
    }
    public void EstablecerValorPorcionYogurt(double n) {
        valorPorcionYogurt = n;
    }

    @Override
    public void calcularPrecioIVA() {
         precioIva = precioBase * (porcentajeIva /100);
    }

    @Override
    public void calcularPrecioFinal() {
        precioFinal= precioBase + valorPorcionFruta + valorPorcionYogurt + precioIva;

    }
    
     public double obtenerValorPorcionFruta() {
        return valorPorcionFruta;
    }
     
      public double obtenerValorPorcionYogurt() {
        return valorPorcionYogurt;
    }
    
      @Override
    public String toString() {
        String cadena = String.format("JUGO NIÑOS"
                + "-----------------------------------\n"
                + "Nombre del Jugo: %s\n"
                + "Precio base: %.2f $\n"
                + "Porcion de frutas: %.2f $"     
                + "Porcion de yogurt: %.2f $"
                + "Porcentaje IVA: %.0f %%\n"
                + "Precio IVA: %.2f $\n"
                + "Precio Final: %.2f $\n",
                obtenerNombreJugo(),
                obtenerPrecioBase(),
                obtenerValorPorcionFruta(),
                obtenerValorPorcionYogurt(),
                obtenerPorcentajeIVA(),
                obtenerPrecioIVA(),
                obtenerPrecioFinal());

        return cadena;
    }
}
