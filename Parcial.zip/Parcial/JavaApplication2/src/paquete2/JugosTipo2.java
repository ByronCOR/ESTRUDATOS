/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;

/**
 *
 * @author utpl
 */
public class JugosTipo2 extends Jugo {

    private double valorPorcionFruta1;
    private double valorPorcionFruta2;
    private double valorPorcionYogurt;

    public JugosTipo2(String a, double b, double c, double vf1, double vf2, double vy) {
        super(a, b, c);
        valorPorcionFruta1 = vf1;
        valorPorcionFruta2 = vf2;
        valorPorcionYogurt = vy;
    }

    public void EstablecerValorPorcionFruta1(double n) {
        valorPorcionFruta1 = n;
    }

    public void EstablecerValorPorcionFruta2(double n) {
        valorPorcionFruta2 = n;
    }

    public void EstablecerValorPorcionYogurt(double n) {
        valorPorcionYogurt = n;
    }

    @Override
    public void calcularPrecioIVA() {
        precioIva = precioBase * (porcentajeIva / 100);
    }

    @Override
    public void calcularPrecioFinal() {
        precioFinal = precioBase + valorPorcionFruta1 
                + valorPorcionFruta2 + valorPorcionYogurt + precioIva;

    }

    public double obtenerValorPorcionFruta1() {
        return valorPorcionFruta1;
    }

    public double obtenerValorPorcionFruta2() {
        return valorPorcionFruta2;
    }

    public double obtenerValorPorcionYogurt() {
        return valorPorcionYogurt;
    }

    @Override
    public String toString() {
        String cadena = String.format("JUGO TIPO 2S"
                + "-----------------------------------\n"
                + "Nombre del Jugo: %s\n"
                + "Precio base: %.2f $\n"
                + "Porcion de frutas 1: %.2f $"
                + "Porcion de frutas 2: %.2f $"
                + "Porcion de yogurt: %.2f $"
                + "Porcentaje IVA: %.0f %%\n"
                + "Precio IVA: %.2f $\n"
                + "Precio Final: %.2f $\n",
                obtenerNombreJugo(),
                obtenerPrecioBase(),
                obtenerValorPorcionFruta1(),
                obtenerValorPorcionFruta2(),
                obtenerValorPorcionYogurt(),
                obtenerPorcentajeIVA(),
                obtenerPrecioIVA(),
                obtenerPrecioFinal());

        return cadena;
    }

}
