/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;

/**
 *
 * @author utpl
 */
abstract class Cliente {

    private String correo;
    private String cedula;
   
    

    public Cliente(String a,String b ) {
        correo = a;
        cedula = b;
    }

    public void establecerCorreo(String n) {
        correo = n;
    }

    public void establecerCedula(String n) {
        cedula = n;
    }

     public String obtenerCorreo() {
        return correo;
    }
     
    public String obtenerCedula() {
        return cedula;
    }
  @Override
    public String toString() {
        String cadena = String.format("\n"
                + "-----------------------------------\n"
                + "Correo del Cliente: %s\n"
                + "Cedula del Cliente: %s\n",
                obtenerCorreo(),
                obtenerCedula());

        return cadena;
    }

    

}
