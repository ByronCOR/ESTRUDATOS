/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete2;

/**
 *
 * @author utpl
 */
public class JugosEconomico extends Jugo {

    private double valorFrutaExtra;

    public JugosEconomico(String a, double b, double c, double v) {
        super(a, b, c);
        valorFrutaExtra = v;
    }
    public void establecerValorFruta(double n) {
        valorFrutaExtra = n;
    }

    @Override
    public void calcularPrecioIVA() {
         precioIva = precioBase * (porcentajeIva /100);
    }

    @Override
    public void calcularPrecioFinal() {
        precioFinal= precioBase + valorFrutaExtra + precioIva;

    }
    
     public double obtenerValorFruta() {
        return valorFrutaExtra;
    }
    
      @Override
    public String toString() {
        String cadena = String.format("JUGO ECONOMICO"
                + "-----------------------------------\n"
                + "Nombre del Jugo: %s\n"
                + "Precio base: %.2f $\n"
                + "Porcion de frutas: %.2f $"
                + "Porcentaje IVA: %.0f %%\n"
                + "Precio IVA: %.2f $\n"
                + "Precio Final: %.2f $\n",
                obtenerNombreJugo(),
                obtenerPrecioBase(),
                obtenerValorFruta(),
                obtenerPorcentajeIVA(),
                obtenerPrecioIVA(),
                obtenerPrecioFinal());

        return cadena;
    }


}
